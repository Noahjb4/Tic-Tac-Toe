# CS611-<Tic-Tac-Toe/>

## Name
---------------------------------------------------------------------------
Noah Jean-Baptiste
noahjb@bu.edu
U20008929

## Files
---------------------------------------------------------------------------
- Files:
Board.java --- Abstract class that represents a grid of Cells
Cell.java --- Class that represents a container for an Object
Checker.java --- Class that extends Piece class and represents an X/O game piece
Game.java --- Interface class represents a playable game controller
Main.java --- Program to begin Tic Tac Toe Game
Piece.java --- Abstract class that represents a game piece
Player.java --- Abstract class that represents a Player in a Game
TicTacToe.java --- Class that implements Game interface and runs Tic Tac Toe Game
TTTBoard.java --- Class that represents a Board for Tic Tac Toe Game
TTTPlayer.java -- Class that represents a Player for Tic Tac Toe Game

## Notes
---------------------------------------------------------------------------

1. only input one number to choose a spot to place your checker.(Friendlier scheme)
2. Attempted the cell array extra credit

## How to run
---------------------------------------------------------------------------
- System: Mac OSX, Intellij IDEA

- Compile: 
1. cd into src file 
2. perform "javac Main.java" command
3. perform "java Main" command